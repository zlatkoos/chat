# Kako biste pokrenuli aplikaciju, kopirajte ju na svoje računalo i pokrenite slijedeće komande:
npm install
npm start